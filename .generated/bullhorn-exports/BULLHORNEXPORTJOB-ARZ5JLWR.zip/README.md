# Bullhorn Export Batch

This ZIP was generated from the Bullhorn REST API for a bounded date range and is formatted to match Hire Gnome's Bullhorn batch importer.

- Updated/created from: 2026-03-23T23:34:00Z
- Updated/created to: 2026-03-26T23:34:00Z
- Changed-row sample limit per entity: 2
- Candidate files included: No

Included files:
- 00-custom-field-definitions.csv (75 rows)
- 01-clients.csv (10 rows)
- 02-contacts.csv (9 rows)
- 03-candidates.csv (8 rows)
- 04-job-orders.csv (7 rows)
- 05-submissions.csv (6 rows)
- 06-interviews.csv (2 rows)
- 07-placements.csv (2 rows)
- 08-candidate-notes.csv (0 rows)
- 09-candidate-educations.csv (2 rows)
- 10-candidate-work-experiences.csv (2 rows)
- 11-contact-notes.csv (0 rows)
- 12-candidate-files.csv (0 rows)

Notes:
- Custom field definitions are included first so custom schema can be created before record import.
- Candidate attachment files were not included in this export.
- The sample limit applies to changed Bullhorn rows per entity before dependency expansion.
- Upstream dependency records may be included even if they fall outside the requested window so imports can link accurately.
- The output is intended for review, testing, and importer compatibility validation.